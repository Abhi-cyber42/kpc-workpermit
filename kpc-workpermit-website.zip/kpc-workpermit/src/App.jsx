import React, { useEffect, useMemo, useState } from "react";
import { createRoot } from "react-dom/client";
import "./style.css";

const STORAGE_KEY = "kpcWorkPermitRecords";

const emptyForm = {
  permitNo: "",
  date: "",
  employeeId: "",
  contractor: "",
  supervisor: "",
  mobile: "",
  email: "",
  location: "",
  permitType: "Hot Work Permit",
  workDescription: "",
  startTime: "",
  endTime: "",
  manpower: "",
  equipment: "",
  hazards: "",
  precautions: "",
  issuedBy: "",
  hseSignature: "",
  approvedBy: "",
  managerSignature: "",
  status: "Pending",
};

const emptyChecklist = {
  ppe: false,
  tbt: false,
  barricading: false,
  fire: false,
  tools: false,
  access: false,
  gas: false,
  emergency: false,
  housekeeping: false,
  illumination: false,
};

const checklistItems = [
  ["ppe", "Required PPE available"],
  ["tbt", "Tool Box Talk conducted"],
  ["barricading", "Barricading and signage provided"],
  ["fire", "Fire extinguisher available"],
  ["tools", "Tools and equipment inspected"],
  ["access", "Safe access and platform provided"],
  ["gas", "Gas test completed where required"],
  ["emergency", "Emergency contact displayed"],
  ["housekeeping", "Good housekeeping maintained"],
  ["illumination", "Proper lighting available"],
];

function buildPermitNumber(date, recordCount) {
  const datePart = date ? date.replaceAll("-", "") : "YYYYMMDD";
  return `KPC-PTW-${datePart}-${String(recordCount + 1).padStart(3, "0")}`;
}

function buildQrText(record) {
  return `Permit No: ${record.permitNo || ""} | Status: ${record.status || ""} | Location: ${record.location || ""}`;
}

function Cell({ title, value, tall }) {
  return (
    <div className={`cell ${tall ? "tall" : ""}`}>
      <div className="cell-title">{title}</div>
      <div className="cell-value">{value || "-"}</div>
    </div>
  );
}

function WideCell({ title, value }) {
  return (
    <div className="cell wide">
      <div className="cell-title">{title}</div>
      <div className="cell-value pre">{value || "-"}</div>
    </div>
  );
}

function PermitPrintView({ record }) {
  if (!record) return null;
  return (
    <section className="permit-print" id="print-permit">
      <div className="print-header">
        <img src="/logo.png" alt="KPC Projects Limited Logo" className="print-logo" />
        <h2>KPC PROJECTS LTD</h2>
        <h3>ONLINE WORK PERMIT</h3>
      </div>

      <div className="print-grid">
        <Cell title="Permit No" value={record.permitNo} />
        <Cell title="Status" value={record.status} />
        <Cell title="Date" value={record.date} />
        <Cell title="Employee ID" value={record.employeeId} />
        <Cell title="Contractor" value={record.contractor} />
        <Cell title="Supervisor" value={record.supervisor} />
        <Cell title="Mobile" value={record.mobile} />
        <Cell title="Email" value={record.email} />
        <Cell title="Location" value={record.location} />
        <Cell title="Permit Type" value={record.permitType} />
        <Cell title="Start Time" value={record.startTime} />
        <Cell title="End Time" value={record.endTime} />
        <WideCell title="Work Description" value={record.workDescription} />
        <WideCell title="Hazards Identified" value={record.hazards} />
        <WideCell title="Safety Precautions" value={record.precautions} />
        <Cell title="Manpower" value={record.manpower} />
        <Cell title="Tools / Equipment" value={record.equipment} />
        <Cell title="Issued By" value={record.issuedBy} />
        <Cell title="Approved By" value={record.approvedBy} />
        <Cell title="HSE Digital Signature" value={record.hseSignature} tall />
        <Cell title="Manager Digital Signature" value={record.managerSignature} tall />
        <Cell title="Submitted At" value={record.submittedAt} />
        <Cell title="Approved At" value={record.approvedAt || "Pending"} />
      </div>

      <h4>Safety Checklist</h4>
      <div className="checklist-print">
        {checklistItems.map(([key, label]) => (
          <div key={key} className="check-row">
            <span>{label}</span>
            <b>{record.checklist?.[key] ? "YES" : "NO"}</b>
          </div>
        ))}
      </div>

      <div className="qr-box">
        <b>QR Approval Code</b>
        <br />
        {record.qrText || buildQrText(record)}
      </div>
    </section>
  );
}

function App() {
  const [isAdmin, setIsAdmin] = useState(false);
  const [login, setLogin] = useState({ user: "", pass: "" });
  const [form, setForm] = useState(emptyForm);
  const [checklist, setChecklist] = useState(emptyChecklist);
  const [selectedPermit, setSelectedPermit] = useState(null);
  const [records, setRecords] = useState(() => {
    try {
      const saved = window.localStorage.getItem(STORAGE_KEY);
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  useEffect(() => {
    try {
      window.localStorage.setItem(STORAGE_KEY, JSON.stringify(records));
    } catch {}
  }, [records]);

  const permitId = useMemo(() => buildPermitNumber(form.date, records.length), [form.date, records.length]);

  const notify = (msg) => window.alert(msg);
  const confirmAction = (msg) => window.confirm(msg);

  const handleChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });
  const handleChecklist = (e) => setChecklist({ ...checklist, [e.target.name]: e.target.checked });

  const adminLogin = (e) => {
    e.preventDefault();
    if (login.user === "admin" && login.pass === "1234") {
      setIsAdmin(true);
      notify("Admin login successful");
    } else {
      notify("Invalid login. Demo login: admin / 1234");
    }
  };

  const resetForm = () => {
    setForm(emptyForm);
    setChecklist(emptyChecklist);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const permitNo = form.permitNo || permitId;
    const newRecord = {
      ...form,
      permitNo,
      checklist: { ...checklist },
      qrText: buildQrText({ ...form, permitNo }),
      submittedAt: new Date().toLocaleString(),
    };
    setRecords([newRecord, ...records]);
    setSelectedPermit(newRecord);
    resetForm();
    notify("Work Permit Submitted Successfully");
  };

  const updateStatus = (index, status) => {
    const updated = records.map((record, i) =>
      i === index
        ? { ...record, status, qrText: buildQrText({ ...record, status }), approvedAt: new Date().toLocaleString() }
        : record
    );
    setRecords(updated);
  };

  const deleteRecord = (index) => {
    if (!confirmAction("Delete this permit record?")) return;
    const deleted = records[index]?.permitNo;
    setRecords(records.filter((_, i) => i !== index));
    if (selectedPermit?.permitNo === deleted) setSelectedPermit(null);
  };

  const clearAllRecords = () => {
    if (!confirmAction("Clear all permit records?")) return;
    setRecords([]);
    setSelectedPermit(null);
  };

  const downloadCSV = () => {
    if (records.length === 0) return notify("No records available to download");
    const headers = ["Permit No", "Date", "Employee ID", "Contractor", "Supervisor", "Mobile", "Email", "Location", "Permit Type", "Description", "Start Time", "End Time", "Manpower", "Equipment", "Hazards", "Precautions", "Issued By", "HSE Signature", "Approved By", "Manager Signature", "Status", "Submitted At", "Approved At"];
    const rows = records.map((r) => [r.permitNo, r.date, r.employeeId, r.contractor, r.supervisor, r.mobile, r.email, r.location, r.permitType, r.workDescription, r.startTime, r.endTime, r.manpower, r.equipment, r.hazards, r.precautions, r.issuedBy, r.hseSignature, r.approvedBy, r.managerSignature, r.status, r.submittedAt, r.approvedAt || ""]);
    const csv = [headers, ...rows].map((row) => row.map((cell) => `"${String(cell ?? "").replaceAll('"', '""')}"`).join(",")).join("\n");
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = window.document.createElement("a");
    a.href = url;
    a.download = "kpc-work-permit-records.csv";
    a.click();
    URL.revokeObjectURL(url);
  };

  const sendEmailNotification = (record) => {
    const subject = encodeURIComponent(`KPC Work Permit ${record.permitNo} - ${record.status}`);
    const body = encodeURIComponent(`Dear Sir,\n\nWork Permit submitted for approval.\n\nPermit No: ${record.permitNo}\nEmployee ID: ${record.employeeId}\nContractor: ${record.contractor}\nSupervisor: ${record.supervisor}\nLocation: ${record.location}\nPermit Type: ${record.permitType}\nStatus: ${record.status}\n\nRegards,\nHSE Department`);
    window.location.href = `mailto:${record.email || ""}?subject=${subject}&body=${body}`;
  };

  const printSelectedPermit = () => {
    if (!selectedPermit) return notify("Please select a permit first.");
    window.print();
  };

  return (
    <div className="page">
      <div className="container">
        <header className="main-header no-print">
          <img src="/logo.png" alt="KPC Projects Limited Logo" className="logo" />
          <h1>KPC PROJECTS LTD</h1>
          <p className="subtitle">Online Work Permit System</p>
          <p className="small">HSE Department | Permit to Work | Digital Approval</p>
        </header>

        <section className="card no-print">
          <h2>Admin Login</h2>
          {!isAdmin ? (
            <form onSubmit={adminLogin} className="login-grid">
              <input placeholder="User: admin" value={login.user} onChange={(e) => setLogin({ ...login, user: e.target.value })} />
              <input placeholder="Password: 1234" type="password" value={login.pass} onChange={(e) => setLogin({ ...login, pass: e.target.value })} />
              <button>Login</button>
              <p className="small">Demo admin approval access</p>
            </form>
          ) : (
            <div className="between">
              <b className="success">Admin logged in: approvals enabled</b>
              <button className="gray" onClick={() => setIsAdmin(false)}>Logout</button>
            </div>
          )}
        </section>

        <section className="stats no-print">
          <div><span>Auto Permit No</span><b>{form.permitNo || permitId}</b></div>
          <div><span>Saved Records</span><b>{records.length}</b></div>
          <div><span>Selected Permit</span><b>{selectedPermit?.permitNo || "None"}</b></div>
          <button className="green" onClick={downloadCSV}>CSV Download</button>
          <button className="red" onClick={clearAllRecords}>Clear All</button>
        </section>

        <form onSubmit={handleSubmit} className="form-grid no-print">
          <Field label="Permit Number"><input name="permitNo" value={form.permitNo} onChange={handleChange} placeholder={permitId} /></Field>
          <Field label="Date"><input required name="date" type="date" value={form.date} onChange={handleChange} /></Field>
          <Field label="Employee ID"><input required name="employeeId" value={form.employeeId} onChange={handleChange} placeholder="KPC / Contractor Employee ID" /></Field>
          <Field label="Contractor Name"><input required name="contractor" value={form.contractor} onChange={handleChange} /></Field>
          <Field label="Supervisor Name"><input required name="supervisor" value={form.supervisor} onChange={handleChange} /></Field>
          <Field label="Mobile Number"><input name="mobile" value={form.mobile} onChange={handleChange} /></Field>
          <Field label="Email for Notification"><input name="email" type="email" value={form.email} onChange={handleChange} placeholder="manager@company.com" /></Field>
          <Field label="Work Location"><input required name="location" value={form.location} onChange={handleChange} /></Field>
          <Field label="Permit Type">
            <select name="permitType" value={form.permitType} onChange={handleChange}>
              <option>Hot Work Permit</option>
              <option>Cold Work Permit</option>
              <option>Work at Height Permit</option>
              <option>Excavation Permit</option>
              <option>Confined Space Permit</option>
              <option>Electrical Work Permit</option>
              <option>Lifting Work Permit</option>
              <option>Night Work Permit</option>
            </select>
          </Field>
          <Field label="Permit Status">
            <select name="status" value={form.status} onChange={handleChange}>
              <option>Pending</option>
              <option>Approved</option>
              <option>Rejected</option>
              <option>Closed</option>
            </select>
          </Field>
          <Field label="Start Time"><input required name="startTime" type="time" value={form.startTime} onChange={handleChange} /></Field>
          <Field label="End Time"><input required name="endTime" type="time" value={form.endTime} onChange={handleChange} /></Field>
          <Field label="Manpower"><input name="manpower" value={form.manpower} onChange={handleChange} placeholder="Example: 10 workers" /></Field>
          <Field label="Tools / Equipment"><input name="equipment" value={form.equipment} onChange={handleChange} placeholder="Example: Welding machine, grinder" /></Field>
          <Field label="Description of Work" wide><textarea required name="workDescription" value={form.workDescription} onChange={handleChange} rows="3" /></Field>
          <Field label="Hazards Identified"><textarea name="hazards" value={form.hazards} onChange={handleChange} rows="3" /></Field>
          <Field label="Safety Precautions"><textarea name="precautions" value={form.precautions} onChange={handleChange} rows="3" /></Field>

          <section className="checklist-section wide-section">
            <h2>Safety Checklist</h2>
            <div className="checklist-grid">
              {checklistItems.map(([key, title]) => (
                <label key={key} className="check-item">
                  <input type="checkbox" name={key} checked={checklist[key]} onChange={handleChecklist} />
                  <span>{title}</span>
                </label>
              ))}
            </div>
          </section>

          <Field label="Issued By / HSE Officer"><input required name="issuedBy" value={form.issuedBy} onChange={handleChange} /></Field>
          <Field label="HSE Digital Signature"><input name="hseSignature" value={form.hseSignature} onChange={handleChange} placeholder="Type full name as digital signature" /></Field>
          <Field label="Approved By / Project Manager"><input name="approvedBy" value={form.approvedBy} onChange={handleChange} /></Field>
          <Field label="Manager Digital Signature"><input name="managerSignature" value={form.managerSignature} onChange={handleChange} placeholder="Type full name as digital signature" /></Field>

          <div className="buttons wide-section">
            <button type="submit" className="primary">Submit Permit Online</button>
            <button type="button" className="gray" onClick={resetForm}>Clear Form</button>
          </div>
        </form>

        {records.length > 0 && (
          <section className="records no-print">
            <h2>Submitted Permit Records</h2>
            <div className="table-wrap">
              <table>
                <thead>
                  <tr>
                    <th>Permit No</th><th>Employee ID</th><th>Date</th><th>Type</th><th>Location</th><th>Supervisor</th><th>Status</th><th>QR Approval</th><th>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {records.map((record, index) => (
                    <tr key={`${record.permitNo}-${index}`}>
                      <td><b>{record.permitNo}</b></td>
                      <td>{record.employeeId}</td>
                      <td>{record.date}</td>
                      <td>{record.permitType}</td>
                      <td>{record.location}</td>
                      <td>{record.supervisor}</td>
                      <td><b>{record.status}</b></td>
                      <td><div className="qr-small">{record.permitNo}<br />{record.status}</div></td>
                      <td>
                        <div className="action-buttons">
                          <button onClick={() => setSelectedPermit(record)}>View</button>
                          <button className="blue" onClick={() => { setSelectedPermit(record); setTimeout(() => window.print(), 100); }}>PDF / Print</button>
                          <button className="purple" onClick={() => sendEmailNotification(record)}>Email</button>
                          <button className="red-light" onClick={() => deleteRecord(index)}>Delete</button>
                          {isAdmin && <>
                            <button className="green-light" onClick={() => updateStatus(index, "Approved")}>Approve</button>
                            <button className="orange-light" onClick={() => updateStatus(index, "Rejected")}>Reject</button>
                            <button className="gray" onClick={() => updateStatus(index, "Closed")}>Close</button>
                          </>}
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </section>
        )}

        {selectedPermit && (
          <div className="print-buttons no-print">
            <button className="primary" onClick={printSelectedPermit}>Print Selected Permit / Save PDF</button>
            <button className="gray" onClick={() => setSelectedPermit(null)}>Hide Permit Preview</button>
          </div>
        )}

        <PermitPrintView record={selectedPermit} />
      </div>
    </div>
  );
}

function Field({ label, children, wide }) {
  return (
    <div className={wide ? "field wide-section" : "field"}>
      <label>{label}</label>
      {children}
    </div>
  );
}

createRoot(document.getElementById("root")).render(<App />);
